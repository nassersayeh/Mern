import React from 'react';
import './styles.css';

const Advertisment = () =>{
    return (
        <div className="advertisment"></div>
    );
}

export default Advertisment;