import React from 'react';
import './styles.css';

const Subcontent =() => {
    return (
        <div className="subcontent"></div>
    );
}

export default Subcontent;