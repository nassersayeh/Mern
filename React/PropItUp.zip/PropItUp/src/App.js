import React from 'react';
import './App.css';
import PersonCardComponent from './components/PersonCardComponent';

function App() {
  return (
    <div className="App">
      <PersonCardComponent firstname = {"Nasser"} lastname = {"Sayeh"} age = {30} haircolor = {"Brown"}/>
      <PersonCardComponent firstname = {"Moath"} lastname = {"Sweidan"} age = {32} haircolor = {"Blond"}/>
      <PersonCardComponent firstname = {"Rahaf"} lastname = {"Hussari"} age = {23} haircolor = {"Black"}/>

    </div>
  );
}

export default App;
