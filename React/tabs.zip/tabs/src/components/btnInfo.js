const btnInfo = [
    {
        label: "Tab 1",
        content: "Tab 1 content shows here",
        color: "Red",
    },
    {
        label: "Tab 2",
        content: "Tab 2 content shows here",
        color: "green",
    },
    {
        label: "Tab 3",
        content: "Tab 3 content shows here",
        color: "blue",
    },
]

export default btnInfo;